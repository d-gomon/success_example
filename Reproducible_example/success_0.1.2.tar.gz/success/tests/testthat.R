library(testthat)
library(success)

test_check("success")
